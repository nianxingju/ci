# GitlabCI Java Service Demo

此项目是GitlabCI项目测试demo
